package lab3_ktnc;

public class ErrorControllerExample {

}
