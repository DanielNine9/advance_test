package fpoly;

import org.testng.annotations.Test;

public class DemoOne {
	@Test
	public void firstTestCase() {
		System.out.println("I'm in first test case from DemoOne Class at fpoly");
	}

	@Test
	public void secondTestCase() {
		System.out.println("I,m in second test case from DemoOne Class at fpoly");
	}
}
