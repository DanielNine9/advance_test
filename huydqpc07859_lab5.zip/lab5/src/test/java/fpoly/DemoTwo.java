package fpoly;

import org.testng.annotations.Test;

public class DemoTwo {
	@Test
	public void firstTestCase() {
		System.out.println("I'm in first test case from DemoTwo Class at fpoly");
	}

	@Test
	public void secondTestCase() {
		System.out.println("I,m in second test case from DemoTwo Class at fpoly");
	}
}
