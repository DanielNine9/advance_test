package huydqpc07859_lab1;

public class Unit {
	int test() {
		return 123;
	}
}
