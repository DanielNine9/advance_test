package huydqpc07859_lab1;

import static org.junit.Assert.*;

import org.junit.Test;

public class UnitTest {

	@Test
	public void test() {
		String s = "Hello world";
		assertEquals("Hello world", s);
	}

}
