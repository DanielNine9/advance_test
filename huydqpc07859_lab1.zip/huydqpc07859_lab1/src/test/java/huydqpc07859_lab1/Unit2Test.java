package huydqpc07859_lab1;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Test;

public class Unit2Test {

	@Test
	public void test() {
		String s = "Hello world";
		assertEquals("Hello world1", s);
	}
}
