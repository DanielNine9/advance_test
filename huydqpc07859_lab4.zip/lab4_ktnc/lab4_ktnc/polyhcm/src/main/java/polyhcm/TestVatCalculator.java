package polyhcm;

public class TestVatCalculator {

}
