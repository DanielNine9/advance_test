package firsttestngpackage;

import org.testng.annotations.Test;

public class FirstTestNGFile {
  @Test
  public void f() {
	  System.out.println("hello world");
  }
}
